 config/ Esta carperta contendra todos los archivos de configuracion 
utils/  Tendra los helpers, funciones que permitiran agilizar los procesos 
public/ Contiene los archivos públicos de la aplicación, como imágenes, CSS o JavaScript.


id_persona:     string
nombre:         string
apellido:       string
direccion:      string 
telefono:       string
correo:         string
CI:             string




 nameInstitution: string
    addressInstitution: string
    typeInstitution:  enum: ['PUBLIC', 'PRIVATE', 'OTHER']
    phoneInstitution: string
    emailInstitution: string
