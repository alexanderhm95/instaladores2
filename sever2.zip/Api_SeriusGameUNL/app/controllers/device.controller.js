const Device = require("../models/devices.model.js");


// Create and Save a new dece
exports.createDevice = async (req, res) => {
    try {
        const { nameDevice, idDevice, connectionDevice } = req.body;

        const device = await Device.create({
            nameDevice,
            idDevice,
            connectionDevice
        });
        res.status(200).send({ message: `Dispositivo ${device.nameDevice} vinculado correctamente ` });
    } catch (error) {

        res.status(400).send({ error: "Error al crear el dispositivo" });
    }
};


exports.getDevice = async (req, res) => {
    try {
        const { nameDevice, connectionDevice } = req.body;

        const device = await Device.findOne({ nameDevice, connectionDevice }).lean();

        if (!device) {
            res.status(200).send({ error: `Dispositivo  no registrado` });
        }

        res.status(200).send({ message: `Dispositivo encontrado correctamente `, data: device });
    } catch (error) {
        res.status(400).send({ error: "Error al encontrar dispositivo" });
    }
}