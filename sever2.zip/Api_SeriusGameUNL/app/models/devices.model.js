const mongoose = require('mongoose');
const { Schema } = mongoose;

const DeviceSchema = new Schema({
    nameDevice: {
        type: String,
        required: true,
    },
    idDevice: {
        type: String,
        required: true,
    },
    connectionDevice: {
        type: String,
        required: true,
    }
},
    {
        timestamps: true,
        versionKey: false
    }
);


// Agrega el índice en el campo 'dece'
DeviceSchema.index({ idDevice: 1 });

const Device = mongoose.model('Device', DeviceSchema);
module.exports = Device;